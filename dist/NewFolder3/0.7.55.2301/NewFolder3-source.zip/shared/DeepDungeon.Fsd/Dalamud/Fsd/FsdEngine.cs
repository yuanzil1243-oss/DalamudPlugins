using global::Dalamud.Interface.Textures;
using global::Dalamud.Plugin.Services;
using System;
using System.Collections.Generic;
using DeepDungeon.Fsd.Core;
using DeepDungeon.Fsd.Runtime;
using DeepDungeon.Fsd.Dalamud.Debug.BgCollision;
using DeepDungeon.Fsd.Dalamud.GameState;
using DeepDungeon.Fsd.Dalamud.Runtime.Helpers;
using FFXIVClientStructs.FFXIV.Client.Game.Event;
using FFXIVClientStructs.FFXIV.Client.Game.InstanceContent;
using DeepDungeon.Fsd.Dalamud.Map;
using DeepDungeon.Fsd.Dalamud.Runtime;
using DeepDungeon.Fsd.Dalamud.Runtime.Entry;

namespace DeepDungeon.Fsd.Dalamud
{
    internal partial class FsdEngine : IDisposable
    {
        private readonly FsdSettings _configuration;
        private readonly FsdExecutionLease _executionLease;
        private readonly string _hostIdentity;
        private readonly string _hostVersion;
        private readonly DetailedMapHostOptions _detailedMapHostOptions;
        private readonly DetailedMapCatalogManager _detailedMapCatalogManager;
        private readonly IFloorEvidenceObserver? _floorEvidenceObserver;
        private readonly IRunTelemetryObserver? _runTelemetryObserver;
        private readonly FsdStartAuthorizationCallback? _tryAuthorizeFsdStart;
        private readonly Func<string?>? _fsdStartDenialNoticeProvider;
        private readonly MasterPlayer.MechanicRuntime.IEncounterSource _encounters;
        private readonly Func<IBossMovementStrategy>? _spinBossMovementFactory;
        private readonly Action<DeepDungeonStateSnapshot>? _stateObserver;
        private readonly NativeDeepDungeonLogMessageSource _logMessageSource;
        private readonly AetherpoolTracker _aetherpoolTracker;

        private readonly FsdRotationController _rotationControl;
        private readonly Runtime.Navigation.FsdCameraController _camera = new();
        
		private RunHost? _ddHost = null;
        private int _fsfScenarioIndex = 1;
        private bool _fsfLoopInfinite = false;
        private int _fsfLoopCount = 1;
        private string? _runLogExportNotice;
        private bool _runLogExportFailed;
        
        private bool _currentInDeepDungeon = false;
        private DeepDungeonStateSnapshot _currentDeepDungeonState = new(
            IsValid: true,
            IsInDeepDungeonTerritory: false,
            IsInDuty: false,
            DungeonId: 0,
            Floor: 0,
            FloorKind: DeepDungeonFloorKind.Unknown,
            IsTransitioning: false,
            Revision: 0);
        private readonly BgCollisionDebugOverlay _bgCollisionDebug = new();
        private bool _showBgCollisionOverlay;
        private readonly Dictionary<uint, PomanderVisual[]> _pomanderVisualCache = new();
		private readonly Dictionary<uint, MagiciteVisual[]> _magiciteVisualCache = new();
        private readonly Dictionary<uint, ISharedImmediateTexture?> _iconTextureCache = new();

        // Shared DD observation and recovery run whenever in deep dungeon, independent of FSD.
        private DutyState? _dutyState;
        private RecoveryPotionHelper? _recoveryPotion;
        private RunContext? _bridgeDeleteSaveContext;
        private GenericDeleteSaveFlow? _bridgeDeleteSaveFlow;
        private DateTime _bridgeDeleteSaveTimeoutAt = DateTime.MinValue;
        private int _bridgeDeleteSaveSlotIndex = -1;
        private string _bridgeDeleteSaveStatus = string.Empty;
        private bool _bridgeDeleteSaveStatusIsError;
        private static readonly TimeSpan BridgeDeleteSaveTimeout = TimeSpan.FromSeconds(45);
        private RunContext? _bridgeLeaveDutyContext;
        private LeaveDutyFlow? _bridgeLeaveDutyFlow;
        private DungeonExitController? _bridgeLeaveDutyRestExitFlow;
        private DateTime _bridgeLeaveDutyTimeoutAt = DateTime.MinValue;
        private string _bridgeLeaveDutyStatus = string.Empty;
        private bool _bridgeLeaveDutyStatusIsError;
        private static readonly TimeSpan BridgeLeaveDutyTimeout = TimeSpan.FromSeconds(75);

        // Passage follow-up when only room center is available
        private bool _pendingPassageFollowup;
        private uint _pendingPassageDungeonId;
        private byte _pendingPassageFloor;
        private int _pendingPassageRoomIndex = -1;
        private DateTime _pendingPassageRetryAt = DateTime.MinValue;
        private DateTime _pendingPassageTimeout = DateTime.MinValue;

        internal FsdEngine(
            FsdSettings configuration,
            MasterPlayer.MechanicRuntime.IEncounterSource encounterSource,
            FsdExecutionLease executionLease,
            string hostIdentity,
            string hostVersion,
            string pluginConfigDirectory,
            DetailedMapHostOptions detailedMapHostOptions,
            IFloorEvidenceObserver? floorEvidenceObserver,
            IRunTelemetryObserver? runTelemetryObserver,
            FsdStartAuthorizationCallback? tryAuthorizeFsdStart = null,
            Func<string?>? fsdStartDenialNoticeProvider = null,
            Func<IBossMovementStrategy>? spinBossMovementFactory = null,
            Action<DeepDungeonStateSnapshot>? stateObserver = null)
        {
            _encounters = encounterSource;
            _configuration = configuration;
            _checkpointPath = Path.Combine(pluginConfigDirectory, "FsdProgressionPause.json");
            LoadProgressionCheckpoint();
            LoadLocalFloorsetPause(pluginConfigDirectory);
            Map.FloorMapSource.Live?.Initialize(pluginConfigDirectory);
            Map.FloorMapSource.Select(_configuration.UseBuiltInFloorMaps);
            _rotationControl = new(ReadRotationState, SetRotationEnabled, RecordRotationControl);
            _executionLease = executionLease;
            _hostIdentity = hostIdentity;
            _hostVersion = hostVersion;
            _detailedMapHostOptions = detailedMapHostOptions;
            _detailedMapCatalogManager = new DetailedMapCatalogManager(
                pluginConfigDirectory,
                detailedMapHostOptions);
            _floorEvidenceObserver = floorEvidenceObserver;
            _runTelemetryObserver = runTelemetryObserver;
            _tryAuthorizeFsdStart = tryAuthorizeFsdStart;
            _fsdStartDenialNoticeProvider = fsdStartDenialNoticeProvider;
            _spinBossMovementFactory = spinBossMovementFactory;
            _stateObserver = stateObserver;
            _logMessageSource = new NativeDeepDungeonLogMessageSource(Service.GameInteropProvider);
            _aetherpoolTracker = new AetherpoolTracker(_logMessageSource);
        }

        internal DutyState? DutyState => _dutyState;
        internal bool IsRunActive => _ddHost?.FsdActive ?? false;
        internal string? ActiveDetailedMapReleaseId =>
            _detailedMapCatalogManager.ActiveRunReleaseId;
        public DeepDungeonStateSnapshot CurrentDeepDungeonState => _currentDeepDungeonState;

        private void EnsureGeneralAssists()
        {
            if (_dutyState != null) return;
            _dutyState = new DutyState();
            _recoveryPotion = new RecoveryPotionHelper(_configuration);
        }

        public void Initialize()
        {
            EnsureGeneralAssists();
            // Subscribe to territory changes
            Service.ClientState.TerritoryChanged += OnTerritoryChanged;
            // Restore persisted scenario selection
            try
            {
                _fsfScenarioIndex = GetEffectiveScenarioIndex();
                _fsfLoopInfinite = _configuration.NecromancerFsdLoopInfinite;
                _fsfLoopCount = Math.Max(1, _configuration.NecromancerFsdLoopCount);
            }
            catch
            {
                _fsfScenarioIndex = 1;
                _fsfLoopInfinite = false;
                _fsfLoopCount = 1;
            }
            
            // Check initial territory state
            CheckDeepDungeonState();
            RefreshDeepDungeonStateSnapshot();
        }

        private int GetEffectiveScenarioIndex()
        {
            if (_configuration.NecromancerFsdScenarioIndex is 4 or 5)
            {
                _configuration.Farming.DungeonId = _configuration.NecromancerFsdScenarioIndex == 4 ? 1u : 2u;
                _configuration.Farming.Mode = FarmingMode.DeepProgression;
                _configuration.NecromancerFsdScenarioIndex = 1;
                _configuration.Save();
            }
            if (_configuration.Farming.DungeonId is not (1 or 2 or 4))
                _configuration.Farming.DungeonId = 4;
            int index = _configuration.Farming.DungeonId == 4
                ? Math.Clamp(_configuration.NecromancerFsdScenarioIndex, 0, 1)
                : 1;
            return index;
        }

        private void OnTerritoryChanged(uint territoryId)
        {
            Map.FloorMap.Reset();
            try
            {
                CheckDeepDungeonState();
            }
            catch (Exception ex)
            {
                Service.Log.Error($"[FsdEngine] Error in OnTerritoryChanged: {ex}");
            }
        }

        private void CheckDeepDungeonState()
        {
            try
            {
                bool wasInDeepDungeon = _currentInDeepDungeon;
                _currentInDeepDungeon = DeepDungeonHelper.IsInDeepDungeon();
                
                if (_currentInDeepDungeon && !wasInDeepDungeon)
                {
                    // Entering deep dungeon - create new state
                    EnterDeepDungeon();
                }
                else if (!_currentInDeepDungeon && wasInDeepDungeon)
                {
                    // Exiting deep dungeon - dispose state
                    ExitDeepDungeon();
                }

                RefreshDeepDungeonStateSnapshot();
            }
            catch (Exception ex)
            {
                Service.Log.Error($"[FsdEngine] Error checking deep dungeon state: {ex}");
            }
        }
        
        private void EnterDeepDungeon()
        {
            try
            {
                // General assists: create if not yet alive
                if (_dutyState == null)
                {
                    EnsureGeneralAssists();
                }

				if (_ddHost == null)
				{
					var dutyState = _dutyState
						?? throw new InvalidOperationException("Shared deep-dungeon state was not initialized.");
					_ddHost = new RunHost(
						_configuration,
                        _encounters,
						dutyState,
						_logMessageSource,
						_floorEvidenceObserver,
						_runTelemetryObserver,
                        _spinBossMovementFactory);
					Service.Log.Info("[FsdEngine] Run host created.");
				}

                TryInvokePalantirFetch();
            }
            catch (Exception ex)
            {
                Service.Log.Error($"[FsdEngine] Error entering deep dungeon: {ex}");
            }
        }
        
        private void ExitDeepDungeon()
        {
            try
            {
                ClearPendingPassageFollowup();
                ResetRoomPresentation();

			bool fsdRunning = _ddHost?.FsdActive == true;
			if (!fsdRunning)
				{
				try { _ddHost?.Dispose(); } catch { }
				_ddHost = null;
					Service.Log.Info("[FsdEngine] Exited deep dungeon - host disposed");
				}
				else
				{
					Service.Log.Info("[FsdEngine] Exited deep dungeon (host kept alive for FSD multi-loop)");
				}

				_dutyState?.MarkOutsideDuty();
				RefreshDeepDungeonStateSnapshot();
				
            }
            catch (Exception ex)
            {
                Service.Log.Error($"[FsdEngine] Error exiting deep dungeon: {ex}");
            }
        }

        internal void SuspendBossMovement() => _ddHost?.FloorController.SuspendBossMovement();

        public void Update(IFramework framework)
        {
            _aetherpoolTracker.Update(_currentInDeepDungeon);
            _fsfScenarioIndex = GetEffectiveScenarioIndex();
            string? selectedDetailedMapScenario =
                GetSelectedDetailedMapScenarioKey();
            _detailedMapCatalogManager.Update(
                _configuration.UseDetailedMap &&
                _detailedMapCatalogManager.HasUsableDetailedMap,
                selectedDetailedMapScenario,
                _ddHost?.FsdActive == true);

            bool dutyStateOk = true;

            // General assists: tick whenever in deep dungeon, independent of FSD.
            if (_currentInDeepDungeon && _dutyState != null)
            {
                dutyStateOk = _dutyState.Update(framework);
                if (dutyStateOk)
                {
                    try { _recoveryPotion?.Update(_currentDeepDungeonState); } catch { }
                }
            }
            else
            {
                _dutyState?.MarkOutsideDuty();
            }
            RefreshDeepDungeonStateSnapshot();

            if (dutyStateOk && _currentInDeepDungeon && _dutyState?.IsTransitioning == false)
                Map.FloorMapSource.ActiveLive?.Observe();
            _stateObserver?.Invoke(_currentDeepDungeonState);
            // Tick the host to allow entry flows outside duty (FSD mode)
            UpdateCompanionControls();
            _ddHost?.Update(framework);
            _camera.Update(_ddHost?.FsdActive == true,
                _ddHost?.FloorController.CameraChestPosition, DateTime.UtcNow,
                _ddHost?.FloorController.BossRequestsNorthCamera == true);
            UpdateCompanionControls();
            if (_detailedMapCatalogManager.ActiveRunSnapshot != null &&
                _ddHost?.FsdActive != true)
            {
                _detailedMapCatalogManager.ReleaseRunSnapshot();
            }
            UpdateLocalPauseLifecycle();
            if (_executionLease.IsHeld && _ddHost?.FsdActive != true)
                _executionLease.Release();
            UpdateBridgeLeaveDuty(framework);
            UpdateBridgeDeleteSaveSlot(framework);
            Coord.NavDebug.Tick();




            if (!dutyStateOk) return;

            if (!_currentInDeepDungeon) return;

            try
            {

                ProcessPendingPassageFollowup();

            }
            catch (Exception ex)
            {
                Service.Log.Error($"[FsdEngine] Error in Update: {ex}");
            }
        }

        private void RefreshDeepDungeonStateSnapshot()
        {
            var duty = _dutyState;
            var candidate = !_currentInDeepDungeon
                ? new DeepDungeonStateSnapshot(
                    IsValid: true,
                    IsInDeepDungeonTerritory: false,
                    IsInDuty: false,
                    DungeonId: 0,
                    Floor: 0,
                    FloorKind: DeepDungeonFloorKind.Unknown,
                    IsTransitioning: false,
                    Revision: _currentDeepDungeonState.Revision)
                : new DeepDungeonStateSnapshot(
                    IsValid: duty != null && !duty.StateReadFailed,
                    IsInDeepDungeonTerritory: true,
                    IsInDuty: duty?.IsInDuty == true,
                    DungeonId: duty?.DungeonId ?? 0,
                    Floor: duty?.Floor ?? 0,
                    FloorKind: duty?.CurrentFloorKind ?? DeepDungeonFloorKind.Unknown,
                    IsTransitioning: duty?.IsTransitioning == true || duty?.IsInDuty != true,
                    Revision: _currentDeepDungeonState.Revision);

            if (_currentDeepDungeonState.SemanticallyEquals(candidate))
                return;

            _currentDeepDungeonState = candidate with
            {
                Revision = checked(_currentDeepDungeonState.Revision + 1)
            };
        }

        private void UpdateBridgeDeleteSaveSlot(IFramework framework)
        {
            if (_bridgeDeleteSaveFlow == null || _bridgeDeleteSaveContext == null)
                return;

            if (DateTime.Now > _bridgeDeleteSaveTimeoutAt)
            {
                _bridgeDeleteSaveStatus = "PT save delete timed out; move to the PT entry NPC and retry if needed.";
                _bridgeDeleteSaveStatusIsError = true;
                StopBridgeDeleteSaveSlotSession();
                return;
            }

            try
            {
                if (_bridgeDeleteSaveFlow.Update(framework))
                {
                    _bridgeDeleteSaveStatus = _bridgeDeleteSaveContext.StatusLine;
                    _bridgeDeleteSaveStatusIsError = _bridgeDeleteSaveContext.StatusIsError;
                    StopBridgeDeleteSaveSlotSession();
                    return;
                }

                _bridgeDeleteSaveStatus = _bridgeDeleteSaveContext.StatusLine;
                _bridgeDeleteSaveStatusIsError = _bridgeDeleteSaveContext.StatusIsError;
            }
            catch (Exception ex)
            {
                _bridgeDeleteSaveStatus = $"PT save delete error: {ex.Message}";
                _bridgeDeleteSaveStatusIsError = true;
                Service.Log.Error($"[FsdEngine] PT save delete bridge session error: {ex}");
                StopBridgeDeleteSaveSlotSession();
            }
        }

        private void StopBridgeDeleteSaveSlotSession()
        {
            try { _bridgeDeleteSaveContext?.Dispose(); } catch { }
            _bridgeDeleteSaveContext = null;
            _bridgeDeleteSaveFlow = null;
            _bridgeDeleteSaveTimeoutAt = DateTime.MinValue;
            _bridgeDeleteSaveSlotIndex = -1;
        }

        private void UpdateBridgeLeaveDuty(IFramework framework)
        {
            if (_bridgeLeaveDutyContext == null)
                return;

            if (DateTime.Now > _bridgeLeaveDutyTimeoutAt)
            {
                _bridgeLeaveDutyStatus = "Leave duty timed out; inspect current duty/rest-room UI before retrying.";
                _bridgeLeaveDutyStatusIsError = true;
                StopBridgeLeaveDutySession();
                return;
            }

            try
            {
                if (_bridgeLeaveDutyContext.Duty.IsInDuty)
                {
                    if (_bridgeLeaveDutyFlow == null)
                    {
                        _bridgeLeaveDutyStatus = "Leave duty flow is unavailable.";
                        _bridgeLeaveDutyStatusIsError = true;
                        StopBridgeLeaveDutySession();
                        return;
                    }

                    if (!_bridgeLeaveDutyFlow.Update(framework))
                    {
                        _bridgeLeaveDutyStatus = _bridgeLeaveDutyContext.StatusLine;
                        _bridgeLeaveDutyStatusIsError = _bridgeLeaveDutyContext.StatusIsError;
                        return;
                    }

                    _bridgeLeaveDutyStatus = "Leave: duty exited; handling PT rest exit.";
                    _bridgeLeaveDutyStatusIsError = false;
                }

                if (_bridgeLeaveDutyRestExitFlow == null)
                {
                    uint npcId = DungeonCatalog.TryGetByDungeonId(_dutyState?.DungeonId ?? 0, out var dd) ? dd.NpcDataId : 0u;
                    _bridgeLeaveDutyRestExitFlow = new DungeonExitController(returnToEntrance: true, entranceNpcBaseId: npcId);
                }
                if (!_bridgeLeaveDutyRestExitFlow.IsPrepared)
                {
                    _bridgeLeaveDutyRestExitFlow.Prepare(_bridgeLeaveDutyContext);
                }

                if (_bridgeLeaveDutyRestExitFlow.Update() != ExitOutcome.Completed)
                {
                    _bridgeLeaveDutyStatus = _bridgeLeaveDutyContext.StatusLine;
                    _bridgeLeaveDutyStatusIsError = _bridgeLeaveDutyContext.StatusIsError;
                    return;
                }

                if (_currentInDeepDungeon)
                {
                    _bridgeLeaveDutyStatus = "Leave: PT rest exit flow complete; waiting for territory exit.";
                    _bridgeLeaveDutyStatusIsError = false;
                    return;
                }

                _bridgeLeaveDutyStatus = "Leave: duty and PT rest exit completed.";
                _bridgeLeaveDutyStatusIsError = false;
                StopBridgeLeaveDutySession();
            }
            catch (Exception ex)
            {
                _bridgeLeaveDutyStatus = $"Leave duty error: {ex.Message}";
                _bridgeLeaveDutyStatusIsError = true;
                Service.Log.Error($"[FsdEngine] Leave duty bridge session error: {ex}");
                StopBridgeLeaveDutySession();
            }
        }

        private void StopBridgeLeaveDutySession()
        {
            try { _bridgeLeaveDutyRestExitFlow?.Dispose(); } catch { }
            try { _bridgeLeaveDutyContext?.Dispose(); } catch { }
            _bridgeLeaveDutyContext = null;
            _bridgeLeaveDutyFlow = null;
            _bridgeLeaveDutyRestExitFlow = null;
            _bridgeLeaveDutyTimeoutAt = DateTime.MinValue;
        }
        

        public void Dispose()
        {
            RestoreAeOutput();
            Map.FloorMapSource.Live?.Dispose();
            _rotationControl.Reset();
            Service.ClientState.TerritoryChanged -= OnTerritoryChanged;
            ResetRoomPresentation();
            _detailedMapCatalogManager.ReleaseRunSnapshot();
            _detailedMapCatalogManager.Dispose();

            
            try { _ddHost?.Dispose(); } catch { }
            _ddHost = null;
            try { _aetherpoolTracker.Dispose(); } catch { }
            try { _logMessageSource.Dispose(); } catch { }
            StopBridgeLeaveDutySession();
            if (_bridgeDeleteSaveContext != null || _bridgeDeleteSaveFlow != null)
                StopBridgeDeleteSaveSlotSession();

            _dutyState = null;
            _recoveryPotion = null;
            if (_executionLease.IsHeld)
                _executionLease.Release();
        }

        private static bool DispatchCompanionCommand(string command)
        {
            // One slash command only: never let a field accidentally send chat.
            string trimmed = command.Trim();
            if (!trimmed.StartsWith('/') || trimmed.IndexOfAny(['\r', '\n', '\0']) >= 0)
            {
                Service.Log.Warning("[FSD] Rejected invalid companion command.");
                return false;
            }
            try
            {
                if (Service.CommandManager.ProcessCommand(trimmed))
                    return true;
                OmenTools.OmenService.ChatManager.Instance().SendMessage(trimmed);
                return true;
            }
            catch (Exception error)
            {
                Service.Log.Error($"[FSD] Companion command failed: {error}");
                return false;
            }
        }
    }
}
