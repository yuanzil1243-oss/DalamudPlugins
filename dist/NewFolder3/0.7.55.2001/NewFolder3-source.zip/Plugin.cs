using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using DeepDungeon.Fsd.Dalamud;
using DeepDungeon.Fsd.Dalamud.Runtime;
using FFXIVClientStructs.Expansion;
using OmenTools;
using OmenTools.OmenService;

namespace NewFolder3;

public sealed class Plugin : IDalamudPlugin, IDisposable
{
    private readonly IDalamudPluginInterface _pluginInterface;
    private readonly ICommandManager _commandManager;
    private readonly IFramework _framework;
    private readonly Configuration _configuration;
    private readonly WindowSystem _windows = new(ProductIdentity.InternalName);
    private readonly INewFolder3AccessGate _accessGate;
    private readonly CommunityEvidenceCollector? _communityEvidenceCollector;
    private readonly CommunityUsageTelemetryCollector? _usageTelemetryCollector;
    private readonly CommunityLongRunLogCollector? _longRunLogCollector;
    private readonly FsdApplication _application;
    private readonly YAxisAdjustController _yAxis;
    private readonly LocalSpeedController _localSpeed;
    private readonly FsdWindow _window;
    private bool _disposed;

    public string Name => ProductIdentity.DisplayName;

    public Plugin(
        IDalamudPluginInterface pluginInterface,
        ICommandManager commandManager,
        IFramework framework,
        IPluginLog pluginLog,
        IObjectTable objectTable,
        IPartyList partyList,
        ISigScanner sigScanner,
        IGameInteropProvider interop,
        IClientState clientState,
        ICondition condition)
    {
        _pluginInterface = pluginInterface ?? throw new ArgumentNullException(nameof(pluginInterface));
        _commandManager = commandManager ?? throw new ArgumentNullException(nameof(commandManager));
        _framework = framework ?? throw new ArgumentNullException(nameof(framework));

        FsdApplication? application = null;
        YAxisAdjustController? yAxis = null;
        LocalSpeedController? localSpeed = null;
        CommunityEvidenceCollector? communityEvidenceCollector = null;
        CommunityUsageTelemetryCollector? usageTelemetryCollector = null;
        CommunityLongRunLogCollector? longRunLogCollector = null;
        var omenInitialized = false;
        var nativeInteropInitialized = false;
        var commandRegistered = false;
        var drawSubscribed = false;
        var configSubscribed = false;
        var frameworkSubscribed = false;

        try
        {
            // ItemSourceManager is unrelated to FSD and starts a raw background build that
            // cannot be cancelled during constructor rollback.
            DService.Init(
                pluginInterface,
                static () => new DServiceInitOptions()
                    .Disable<ItemSourceManager>()
                    .Disable<LogMessageManager>()
                    .Disable<TargetManager>()
                    .Disable<UseActionManager>());
            omenInitialized = true;
            nativeInteropInitialized = true;
            ExpansionInterop.Initialize(sigScanner.SearchBase);

            LocalConfigurationUpgrade.Prepare(pluginInterface, pluginLog);
            _configuration =
                pluginInterface.GetPluginConfig() as Configuration ?? new Configuration();
            _configuration.Initialize(pluginInterface);
            DeleteLegacyRejectedUploads(pluginInterface.GetPluginConfigDirectory(), pluginLog);
            _accessGate = NewFolder3BuildProfile.CreateAccessGate(pluginInterface, pluginLog);
            string hostVersion = typeof(Plugin).Assembly.GetName().Version?.ToString()
                ?? throw new InvalidOperationException("Standalone host version is unavailable.");

            NewFolder3BuildCapabilities capabilities = NewFolder3BuildProfile.Capabilities;
            string? installationToken = null;
            if (capabilities.CommunityEvidenceEndpoint != null ||
                capabilities.UsageTelemetryEndpoint != null ||
                capabilities.LongRunLogEndpoint != null)
            {
                installationToken =
                    _configuration.GetOrCreateCommunityEvidenceInstallationToken();
            }

            if (capabilities.CommunityEvidenceEndpoint is { } evidenceEndpoint)
            {
                communityEvidenceCollector = new CommunityEvidenceCollector(
                    pluginInterface.GetPluginConfigDirectory(),
                    installationToken
                        ?? throw new InvalidOperationException(
                            "Installation token is required for community evidence upload."),
                    evidenceEndpoint,
                    pluginLog);
            }
            if (capabilities.UsageTelemetryEndpoint is { } telemetryEndpoint)
            {
                usageTelemetryCollector = new CommunityUsageTelemetryCollector(
                    pluginInterface.GetPluginConfigDirectory(),
                    installationToken
                        ?? throw new InvalidOperationException(
                            "Installation token is required for usage telemetry."),
                    hostVersion,
                    telemetryEndpoint,
                    pluginLog);
            }
            if (capabilities.LongRunLogEndpoint is { } longRunLogEndpoint)
            {
                longRunLogCollector = new CommunityLongRunLogCollector(
                    pluginInterface.GetPluginConfigDirectory(),
                    installationToken
                        ?? throw new InvalidOperationException(
                            "Installation token is required for long-run log upload."),
                    hostVersion,
                    longRunLogEndpoint,
                    pluginLog);
            }

            _communityEvidenceCollector = communityEvidenceCollector;
            _usageTelemetryCollector = usageTelemetryCollector;
            _longRunLogCollector = longRunLogCollector;

            IRunTelemetryObserver? runTelemetryObserver =
                usageTelemetryCollector != null && longRunLogCollector != null
                    ? new CompositeRunTelemetryObserver(
                        usageTelemetryCollector,
                        longRunLogCollector)
                    : usageTelemetryCollector ?? (IRunTelemetryObserver?)longRunLogCollector;

            // FsdApplication injects the shared Dalamud services required by FSD.
            var yAxisController = new YAxisAdjustController(_configuration, objectTable, partyList, pluginLog);
            yAxis = yAxisController;
            _yAxis = yAxisController;
            application = FsdApplication.CreateStandalone(
                pluginInterface,
                _configuration,
                ProductIdentity.HostIdentity,
                hostVersion,
                NewFolder3BuildProfile.CreateDetailedMapHostOptions(),
                playerYOffsetProvider: () => yAxisController.ActualYOffset,
                floorEvidenceObserver: _communityEvidenceCollector,
                runTelemetryObserver: runTelemetryObserver,
                tryAuthorizeFsdStart: _accessGate.TryAuthorizeFsdStart,
                fsdStartDenialNoticeProvider: () => _accessGate.FsdStartDenialNotice);
            _application = application;

            localSpeed = new LocalSpeedController(_configuration, () => _application.IsRunActive,
                clientState, condition, objectTable, sigScanner, interop, pluginLog);
            _localSpeed = localSpeed;
            _window = new FsdWindow(_application, _yAxis, _localSpeed);
            _windows.AddWindow(_window);

            _commandManager.AddHandler(ProductIdentity.Command, new CommandInfo(OnCommand)
            {
                HelpMessage = $"Open {ProductIdentity.DisplayName} Deep Dungeon FSD."
            });
            commandRegistered = true;

            _pluginInterface.UiBuilder.Draw += Draw;
            drawSubscribed = true;
            _pluginInterface.UiBuilder.OpenConfigUi += OpenWindow;
            configSubscribed = true;
            _framework.Update += OnFrameworkUpdate;
            frameworkSubscribed = true;
        }
        catch (Exception startupError)
        {
            var rollbackErrors = new List<Exception>();
            RollBack(() => { if (frameworkSubscribed) _framework.Update -= OnFrameworkUpdate; }, rollbackErrors);
            RollBack(() => { if (configSubscribed) _pluginInterface.UiBuilder.OpenConfigUi -= OpenWindow; }, rollbackErrors);
            RollBack(() => { if (drawSubscribed) _pluginInterface.UiBuilder.Draw -= Draw; }, rollbackErrors);
            RollBack(() => { if (commandRegistered) _commandManager.RemoveHandler(ProductIdentity.Command); }, rollbackErrors);
            RollBack(_windows.RemoveAllWindows, rollbackErrors);
            RollBack(() => localSpeed?.Dispose(), rollbackErrors);
            RollBack(() => yAxis?.Dispose(), rollbackErrors);
            RollBack(() => application?.Dispose(), rollbackErrors);
            RollBack(() => communityEvidenceCollector?.Dispose(), rollbackErrors);
            RollBack(() => usageTelemetryCollector?.Dispose(), rollbackErrors);
            RollBack(() => longRunLogCollector?.Dispose(), rollbackErrors);
            RollBack(() => { if (nativeInteropInitialized) ExpansionInterop.Uninitialize(); }, rollbackErrors);
            RollBack(() => { if (omenInitialized) DService.Uninit(); }, rollbackErrors);

            if (rollbackErrors.Count == 0)
                throw;

            rollbackErrors.Insert(0, startupError);
            throw new AggregateException("Standalone FSD startup and rollback both failed.", rollbackErrors);
        }
    }

    private static void DeleteLegacyRejectedUploads(string configDirectory, IPluginLog log)
    {
        foreach (string spool in new[] { "DetailedMapEvidence", "UsageTelemetry", "LongRunLogs" })
        {
            string directory = Path.Combine(configDirectory, spool, "rejected");
            if (!Directory.Exists(directory))
                continue;
            try
            {
                foreach (string file in Directory.EnumerateFiles(directory))
                {
                    try { File.Delete(file); }
                    catch (Exception error) when (error is IOException or UnauthorizedAccessException)
                    { log.Warning(error, "Rejected upload could not be deleted: {FileName}", Path.GetFileName(file)); }
                }
            }
            catch (Exception error) when (error is IOException or UnauthorizedAccessException)
            { log.Warning(error, "Rejected upload directory could not be cleaned: {Spool}", spool); }
        }
    }

    private static void RollBack(Action action, List<Exception> errors)
    {
        try
        {
            action();
        }
        catch (Exception error)
        {
            errors.Add(error);
        }
    }

    private void Draw()
    {
        _windows.Draw();
        _yAxis.DrawOverlay();
    }

    private void OnFrameworkUpdate(IFramework framework)
    {
        _localSpeed.Update();
        try { _application.Update(framework); }
        catch { _localSpeed.RevokeForHostError(); throw; }
        finally { _localSpeed.ReleaseIfStopped(); }
        _yAxis.Update(_application.CurrentDeepDungeonState);
        _communityEvidenceCollector?.ObserveRunState(
            _application.IsRunActive,
            _configuration.Fsd.UseDetailedMap,
            _application.ActiveDetailedMapReleaseId);
        _usageTelemetryCollector?.ObserveRunState(
            _application.IsRunActive,
            _configuration.Fsd.UseDetailedMap,
            CommunityUsageTelemetryScenarios.MapScenarioIndex(
                _configuration.Fsd.NecromancerFsdScenarioIndex));
    }

    private void OnCommand(string command, string arguments)
    {
        var args = arguments.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (args.Length > 0 && args[0].Equals("fsd", StringComparison.OrdinalIgnoreCase))
            _application.HandleCommand(args[1..]);
        else
            _window.Toggle();
    }
    private void OpenWindow() => _window.IsOpen = true;

    public void Dispose()
    {
        if (_disposed)
            return;
        _framework.Update -= OnFrameworkUpdate;
        _pluginInterface.UiBuilder.OpenConfigUi -= OpenWindow;
        _pluginInterface.UiBuilder.Draw -= Draw;
        _commandManager.RemoveHandler(ProductIdentity.Command);
        _windows.RemoveAllWindows();
        _localSpeed.Dispose();
        _yAxis.Dispose();
        _application.Dispose();
        _communityEvidenceCollector?.Dispose();
        _usageTelemetryCollector?.Dispose();
        _longRunLogCollector?.Dispose();
        ExpansionInterop.Uninitialize();
        DService.Uninit();
        _disposed = true;
    }
}
