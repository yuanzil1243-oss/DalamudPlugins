using BossMod.SMN;
using static BossMod.AIHints;

namespace BossMod.Autorotation.akechi;

public sealed class AkechiSMNPvP(RotationModuleManager manager, Actor player) : AkechiTools<AID, TraitID>(manager, player)
{
    public enum Track { Targeting, RoleActions, LimitBreak, Placement, RadiantAegis, RuinIV, CrimsonCyclone, MountainBuster, Slipstream, Necrotize }
    public enum TargetingStrategy { Auto, Manual }
    public enum RoleActionStrategy { Forbid, Comet, PhantomDart, Rust }
    public enum LBStrategy { Bahamut, Phoenix, Forbid }
    public enum LBPlacement { Self, Target, Crystal, CrystalOrTarget }
    public enum AegisStrategy { Auto, Two, Three, Four, LessThanFull, LessThan75, LessThan50, Forbid }
    public enum Ruin4Strategy { Early, Late, Forbid }
    public enum CycloneStrategy { Five, Ten, Fifteen, Twenty, Allow, Forbid }
    public enum CommonStrategy { Allow, Forbid }

    public static RotationModuleDefinition Definition()
    {
        var res = new RotationModuleDefinition("Akechi SMN (PvP)", "PvP Rotation Module", "PvP", "Akechi", RotationModuleQuality.Basic, BitMask.Build((int)Class.SMN), 100, 30);
        res.Define(Track.Targeting).As<TargetingStrategy>("Targeting", "", 300)
            .AddOption(TargetingStrategy.Auto, "Automatically select best target")
            .AddOption(TargetingStrategy.Manual, "Manually select target");

        res.Define(Track.RoleActions).As<RoleActionStrategy>("Role Actions", "", 300)
            .AddOption(RoleActionStrategy.Forbid, "Do not use any role actions")
            .AddOption(RoleActionStrategy.Comet, "Use Comet when available")
            .AddOption(RoleActionStrategy.PhantomDart, "Use Phantom Dart when available")
            .AddOption(RoleActionStrategy.Rust, "Use Rust when available")
            .AddAssociatedActions(AID.CometPvP, AID.PhantomDartPvP, AID.RustPvP);

        res.Define(Track.LimitBreak).As<LBStrategy>("LB Summon", "", 300)
            .AddOption(LBStrategy.Bahamut, "Allow use of Bahamut only for Limit Break when available")
            .AddOption(LBStrategy.Phoenix, "Allow use of Phoenix only for Limit Break when available")
            .AddOption(LBStrategy.Forbid, "Do not use Limit Break")
            .AddAssociatedActions(AID.SummonBahamutPvP, AID.SummonPhoenixPvP);

        res.Define(Track.Placement).As<LBPlacement>("LB Placement", "", 300)
            .AddOption(LBPlacement.Self, "Place Limit Break summon on self")
            .AddOption(LBPlacement.Target, "Place Limit Break summon on current target")
            .AddOption(LBPlacement.Crystal, "Place Limit Break summon on crystal only; will hold LB until near the crystal (only works for Crystalline Conflict)")
            .AddOption(LBPlacement.CrystalOrTarget, "Place Limit Break summon on crystal or target if crystal is unavailable (intended for Crystalline Conflict, but works in others too)");

        res.Define(Track.RadiantAegis).As<AegisStrategy>("Radiant Aegis", "", 300)
            .AddOption(AegisStrategy.Auto, "Use Radiant Aegis when HP is less than 75% and two or more targets are targeting you, or when HP is below 33%")
            .AddOption(AegisStrategy.Two, "Use Radiant Aegis when HP is not full and two or more targets are targeting you")
            .AddOption(AegisStrategy.Three, "Use Radiant Aegis when HP is not full and three or more targets are targeting you")
            .AddOption(AegisStrategy.Four, "Use Radiant Aegis when HP is not full and four or more targets are targeting you")
            .AddOption(AegisStrategy.LessThanFull, "Use Radiant Aegis when HP is less than 100%")
            .AddOption(AegisStrategy.LessThan75, "Use Radiant Aegis when HP is less than 75%")
            .AddOption(AegisStrategy.LessThan50, "Use Radiant Aegis when HP is less than 50%")
            .AddOption(AegisStrategy.Forbid, "Do not use Radiant Aegis")
            .AddAssociatedActions(AID.RadiantAegisPvP);

        res.Define(Track.RuinIV).As<Ruin4Strategy>("Ruin IV", "", 300)
            .AddOption(Ruin4Strategy.Early, "Use Ruin IV as soon as it is available")
            .AddOption(Ruin4Strategy.Late, "Use Ruin IV as late as possible")
            .AddOption(Ruin4Strategy.Forbid, "Do not use Ruin IV")
            .AddAssociatedActions(AID.Ruin4PvP);

        res.Define(Track.CrimsonCyclone).As<CycloneStrategy>("Crimson Cyclone", "", 300)
            .AddOption(CycloneStrategy.Five, "Use Crimson Cyclone only within 5 yalms of target")
            .AddOption(CycloneStrategy.Ten, "Use Crimson Cyclone only within 10 yalms of target")
            .AddOption(CycloneStrategy.Fifteen, "Use Crimson Cyclone only within 15 yalms of target")
            .AddOption(CycloneStrategy.Twenty, "Use Crimson Cyclone only within 20 yalms of target")
            .AddOption(CycloneStrategy.Allow, "Use Crimson Cyclone when available at any range")
            .AddOption(CycloneStrategy.Forbid, "Do not use Crimson Cyclone")
            .AddAssociatedActions(AID.CrimsonCyclonePvP);

        res.Define(Track.MountainBuster).As<CommonStrategy>("Mountain Buster", "", 300)
            .AddOption(CommonStrategy.Allow, "Use Mountain Buster when available")
            .AddOption(CommonStrategy.Forbid, "Do not use Mountain Buster")
            .AddAssociatedActions(AID.MountainBusterPvP);

        res.Define(Track.Slipstream).As<CommonStrategy>("Slipstream", "", 300)
            .AddOption(CommonStrategy.Allow, "Use Slipstream when available")
            .AddOption(CommonStrategy.Forbid, "Do not use Slipstream")
            .AddAssociatedActions(AID.SlipstreamPvP);

        res.Define(Track.Necrotize).As<CommonStrategy>("Necrotize", "", 300)
            .AddOption(CommonStrategy.Allow, "Use Necrotize when available")
            .AddOption(CommonStrategy.Forbid, "Do not use Necrotize")
            .AddAssociatedActions(AID.NecrotizePvP);

        return res;
    }

    public bool IsReady(AID aid) => Cooldown(aid) <= 0.2f;

    public override void Execution(StrategyValues strategy, Enemy? primaryTarget)
    {
        if (Player.IsDeadOrDestroyed || Player.MountId != 0 || Player.FindStatus(ClassShared.SID.GuardPvP) != null)
            return;

        var (BestConeTargets, NumConeTargets) = GetBestTarget(primaryTarget, 8, ConeTargetCheck(8));
        var (BestSplashTargets, NumSplashTargets) = GetBestTarget(primaryTarget, 25, IsSplashTarget);
        var (BestSlipstreamTargets, NumSlipstreamTargets) = GetBestTarget(primaryTarget, 25, Is10ySplashTarget);
        var BestConeTarget = NumConeTargets > 1 ? BestConeTargets : primaryTarget;
        var BestSplashTarget = NumSplashTargets > 1 ? BestSplashTargets : primaryTarget;
        var BestSlipstreamTarget = NumSlipstreamTargets > 1 ? BestSlipstreamTargets : primaryTarget;
        var mainTarget = primaryTarget?.Actor;
        var auto = strategy.Option(Track.Targeting).As<TargetingStrategy>() == TargetingStrategy.Auto;
        var BestTarget = auto ? BestSplashTarget?.Actor : mainTarget;

        if (auto)
        {
            GetPvPTarget(25);
        }

        if (In25y(mainTarget) && HasLOS(mainTarget))
        {
            if (World.Party.LimitBreakLevel >= 1)
            {
                var crystal = World.Actors.FirstOrDefault(x => x.OID == 0x3886); //crystal
                var summon = strategy.Option(Track.LimitBreak).As<LBStrategy>() switch
                {
                    LBStrategy.Bahamut => AID.SummonBahamutPvP,
                    LBStrategy.Phoenix => AID.SummonPhoenixPvP,
                    _ => AID.None
                };
                var placement = strategy.Option(Track.Placement).As<LBPlacement>() switch
                {
                    LBPlacement.Self => Player,
                    LBPlacement.Target => mainTarget,
                    LBPlacement.Crystal => crystal,
                    LBPlacement.CrystalOrTarget => crystal ?? mainTarget,
                    _ => null
                };
                QueueGCD(summon, placement, GCDPriority.High + 1);
            }

            var (roleCondition, roleAction, roleTarget) = strategy.Option(Track.RoleActions).As<RoleActionStrategy>() switch
            {
                RoleActionStrategy.Comet => (HasStatus(SID.CometEquippedPvP) && IsReady(AID.CometPvP) && !IsMoving, AID.CometPvP, auto ? BestSlipstreamTarget?.Actor : mainTarget),
                RoleActionStrategy.PhantomDart => (HasStatus(SID.PhantomDartEquippedPvP) && IsReady(AID.PhantomDartPvP), AID.PhantomDartPvP, mainTarget),
                RoleActionStrategy.Rust => (HasStatus(SID.RustEquippedPvP) && IsReady(AID.RustPvP), AID.RustPvP, mainTarget),
                _ => (false, AID.None, null)
            };
            if (roleCondition)
                QueueGCD(roleAction, roleTarget, GCDPriority.High + 1);

            if (IsReady(AID.BrandOfPurgatoryPvP) && HasStatus(SID.FirebirdTrance))
                QueueGCD(AID.BrandOfPurgatoryPvP, BestTarget, GCDPriority.High);

            if (IsReady(AID.DeathflarePvP) && HasStatus(SID.DreadwyrmTrance))
                QueueGCD(AID.DeathflarePvP, BestTarget, GCDPriority.High);

            if (IsReady(AID.Ruin4PvP) && HasStatus(SID.FurtherRuinPvP))
            {
                var (r4Condition, r4Priority) = strategy.Option(Track.RuinIV).As<Ruin4Strategy>() switch
                {
                    Ruin4Strategy.Early => (true, GCDPriority.High + 1),
                    Ruin4Strategy.Late => (Status(SID.FurtherRuinPvP) <= 3f || Cooldown(AID.NecrotizePvP) <= 1f, GCDPriority.ModeratelyHigh),
                    _ => (false, GCDPriority.None)
                };
                if (r4Condition)
                    QueueGCD(AID.Ruin4PvP, BestTarget, r4Priority);
            }

            if (Cooldown(AID.NecrotizePvP) < 10.6f && !HasStatus(SID.FurtherRuinPvP) && strategy.Option(Track.Necrotize).As<CommonStrategy>() == CommonStrategy.Allow)
                QueueGCD(AID.NecrotizePvP, mainTarget, GCDPriority.SlightlyHigh);

            if (IsReady(AID.CrimsonCyclonePvP) && strategy.Option(Track.CrimsonCyclone).As<CycloneStrategy>() switch
            {
                CycloneStrategy.Five => In5y(BestTarget),
                CycloneStrategy.Ten => In10y(BestTarget),
                CycloneStrategy.Fifteen => In15y(BestTarget),
                CycloneStrategy.Twenty => In20y(BestTarget),
                CycloneStrategy.Allow => true,
                _ => false
            })
                QueueGCD(AID.CrimsonCyclonePvP, BestTarget, GCDPriority.AboveAverage);

            if (HasStatus(SID.CrimsonStrikeReadyPvP))
                QueueGCD(AID.CrimsonStrikePvP, mainTarget, Status(SID.FurtherRuinPvP) <= 3f ? GCDPriority.High + 1 : GCDPriority.AboveAverage);

            if (IsReady(AID.MountainBusterPvP) && DistanceFrom(mainTarget, 8f) && strategy.Option(Track.MountainBuster).As<CommonStrategy>() == CommonStrategy.Allow)
                QueueGCD(AID.MountainBusterPvP, auto ? BestConeTarget?.Actor : mainTarget, GCDPriority.Average);

            if (IsReady(AID.SlipstreamPvP) && !IsMoving && strategy.Option(Track.Slipstream).As<CommonStrategy>() == CommonStrategy.Allow)
                QueueGCD(AID.SlipstreamPvP, BestSlipstreamTarget?.Actor, GCDPriority.BelowAverage);

            if (IsReady(AID.AstralImpulsePvP) && HasStatus(SID.DreadwyrmTrance))
                QueueGCD(AID.AstralImpulsePvP, mainTarget, GCDPriority.SlightlyLow);

            if (IsReady(AID.FountainOfFirePvP) && HasStatus(SID.FirebirdTrance))
                QueueGCD(AID.FountainOfFirePvP, mainTarget, GCDPriority.SlightlyLow);

            if (IsReady(AID.RadiantAegisPvP) && strategy.Option(Track.RadiantAegis).As<AegisStrategy>() switch
            {
                AegisStrategy.Auto => (PlayerHPP is < 75 and not 0 && EnemiesTargetingSelf(2)) || PlayerHPP is < 33 and not 0,
                AegisStrategy.Two => EnemiesTargetingSelf(2) && PlayerHPP is < 100 and not 0,
                AegisStrategy.Three => EnemiesTargetingSelf(3) && PlayerHPP is < 100 and not 0,
                AegisStrategy.Four => EnemiesTargetingSelf(4) && PlayerHPP is < 100 and not 0,
                AegisStrategy.LessThanFull => PlayerHPP is < 100 and not 0,
                AegisStrategy.LessThan75 => PlayerHPP is < 75 and not 0,
                AegisStrategy.LessThan50 => PlayerHPP is < 50 and not 0,
                _ => false
            })
                QueueGCD(AID.RadiantAegisPvP, mainTarget, GCDPriority.Max);

            QueueGCD(AID.Ruin3PvP, mainTarget, GCDPriority.Low);
        }
    }
}
